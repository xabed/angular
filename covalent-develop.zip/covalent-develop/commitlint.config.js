var defaultConfig = require('./src/platform/coding-standards/commitlint/commitlint.config.js');
module.exports = defaultConfig;
