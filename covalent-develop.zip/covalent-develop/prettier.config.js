var defaultConfig = require('./src/platform/coding-standards/prettier/prettier.config.js');
module.exports = defaultConfig;
