import { Component } from '@angular/core';

@Component({
  selector: 'td-component-hero',
  templateUrl: './component-hero.component.html',
  styleUrls: ['./component-hero.component.scss'],
})
export class ComponentHeroComponent {
  resourceUrl: any;
}
