import { Component } from '@angular/core';

@Component({
  selector: 'breadcrumbs-demo',
  styleUrls: ['./breadcrumbs.component.scss'],
  templateUrl: './breadcrumbs.component.html',
  preserveWhitespaces: true,
})
export class BreadcrumbDemoComponent {}
