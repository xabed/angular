import { Component } from '@angular/core';

@Component({
  selector: 'breadcrumbs-demo-basic',
  styleUrls: ['./breadcrumbs-demo-basic.component.scss'],
  templateUrl: './breadcrumbs-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class BreadcrumbsDemoBasicComponent {}
