import { Component } from '@angular/core';

@Component({
  selector: 'breadcrumbs-demo',
  styleUrls: ['./breadcrumbs-demo.component.scss'],
  templateUrl: './breadcrumbs-demo.component.html',
})
export class BreadcrumbsDemoComponent {}
