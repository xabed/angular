import { Component } from '@angular/core';

@Component({
  selector: 'chips-demo',
  styleUrls: ['./chips-demo.component.scss'],
  templateUrl: './chips-demo.component.html',
})
export class ChipsDemoComponent {}
