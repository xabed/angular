import { Component } from '@angular/core';

@Component({
  selector: 'code-editor-demo',
  styleUrls: ['./code-editor-demo.component.scss'],
  templateUrl: './code-editor-demo.component.html',
})
export class CodeEditorDemoComponent {}
