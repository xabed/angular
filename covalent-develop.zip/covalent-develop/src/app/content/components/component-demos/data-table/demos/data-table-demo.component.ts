import { Component } from '@angular/core';

@Component({
  selector: 'data-table-demo',
  styleUrls: ['./data-table-demo.component.scss'],
  templateUrl: './data-table-demo.component.html',
})
export class DataTableDemoComponent {}
