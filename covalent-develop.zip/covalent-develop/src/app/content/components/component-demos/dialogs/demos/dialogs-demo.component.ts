import { Component } from '@angular/core';

@Component({
  selector: 'dialogs-demo',
  styleUrls: ['./dialogs-demo.component.scss'],
  templateUrl: './dialogs-demo.component.html',
})
export class DialogsDemoComponent {}
