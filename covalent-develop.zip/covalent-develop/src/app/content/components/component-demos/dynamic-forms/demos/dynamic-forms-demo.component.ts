import { Component } from '@angular/core';

@Component({
  selector: 'dynamic-forms-demo',
  styleUrls: ['./dynamic-forms-demo.component.scss'],
  templateUrl: './dynamic-forms-demo.component.html',
})
export class DynamicFormsDemoComponent {}
