import { Component } from '@angular/core';

@Component({
  selector: 'file-input-demo-basic',
  styleUrls: ['./file-input-demo-basic.component.scss'],
  templateUrl: './file-input-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class FileInputDemoBasicComponent {
  files: any;
}
