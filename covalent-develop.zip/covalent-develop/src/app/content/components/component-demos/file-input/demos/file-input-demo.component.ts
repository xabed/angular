import { Component } from '@angular/core';

@Component({
  selector: 'file-input-demo',
  styleUrls: ['./file-input-demo.component.scss'],
  templateUrl: './file-input-demo.component.html',
})
export class FileInputDemoComponent {}
