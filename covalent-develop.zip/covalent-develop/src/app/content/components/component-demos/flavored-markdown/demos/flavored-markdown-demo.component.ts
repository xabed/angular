import { Component } from '@angular/core';

@Component({
  selector: 'flavored-markdown-demo',
  styleUrls: ['./flavored-markdown-demo.component.scss'],
  templateUrl: './flavored-markdown-demo.component.html',
})
export class FlavoredMarkdownDemoComponent {}
