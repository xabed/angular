import { Component } from '@angular/core';

@Component({
  selector: 'flavored-markdown-demo',
  styleUrls: ['./flavored-markdown.component.scss'],
  templateUrl: './flavored-markdown.component.html',
  preserveWhitespaces: true,
})
export class FlavoredMarkdownDemoComponent {}
