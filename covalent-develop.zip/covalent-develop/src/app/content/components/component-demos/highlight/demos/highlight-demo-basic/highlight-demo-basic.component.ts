import { Component } from '@angular/core';

@Component({
  selector: 'highlight-demo-basic',
  styleUrls: ['./highlight-demo-basic.component.scss'],
  templateUrl: './highlight-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class HighlightDemoBasicComponent {}
