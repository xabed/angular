import { Component } from '@angular/core';

@Component({
  selector: 'highlight-demo',
  styleUrls: ['./highlight-demo.component.scss'],
  templateUrl: './highlight-demo.component.html',
})
export class HighlightDemoComponent {}
