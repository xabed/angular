import { Component } from '@angular/core';

@Component({
  selector: 'highlight-demo',
  styleUrls: ['./highlight.component.scss'],
  templateUrl: './highlight.component.html',
  preserveWhitespaces: true,
})
export class HighlightDemoComponent {}
