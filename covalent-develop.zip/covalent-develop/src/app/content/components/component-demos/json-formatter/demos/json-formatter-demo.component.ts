import { Component } from '@angular/core';

@Component({
  selector: 'json-formatter-demo',
  styleUrls: ['./json-formatter-demo.component.scss'],
  templateUrl: './json-formatter-demo.component.html',
})
export class JsonFormatterDemoComponent {}
