import { Component } from '@angular/core';

@Component({
  selector: 'layout-card-over-demo-basic',
  styleUrls: ['./layout-card-over-demo-basic.component.scss'],
  templateUrl: './layout-card-over-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class LayoutCardOverDemoBasicComponent {}
