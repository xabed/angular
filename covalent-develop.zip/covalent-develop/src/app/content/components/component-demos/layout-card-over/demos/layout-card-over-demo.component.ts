import { Component } from '@angular/core';

@Component({
  selector: 'layout-card-over-demo',
  styleUrls: ['./layout-card-over-demo.component.scss'],
  templateUrl: './layout-card-over-demo.component.html',
})
export class LayoutCardOverDemoComponent {}
