import { Component } from '@angular/core';

@Component({
  selector: 'layout-management-list-demo-basic',
  styleUrls: ['./layout-management-list-demo-basic.component.scss'],
  templateUrl: './layout-management-list-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class LayoutManagementListDemoBasicComponent {}
