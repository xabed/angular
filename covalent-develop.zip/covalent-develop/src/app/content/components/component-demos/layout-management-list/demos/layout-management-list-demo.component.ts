import { Component } from '@angular/core';

@Component({
  selector: 'layout-management-list-demo',
  styleUrls: ['./layout-management-list-demo.component.scss'],
  templateUrl: './layout-management-list-demo.component.html',
})
export class LayoutManagementListDemoComponent {}
