import { Component } from '@angular/core';

@Component({
  selector: 'layout-nav-list-demo-basic',
  styleUrls: ['./layout-nav-list-demo-basic.component.scss'],
  templateUrl: './layout-nav-list-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class LayoutNavListDemoBasicComponent {}
