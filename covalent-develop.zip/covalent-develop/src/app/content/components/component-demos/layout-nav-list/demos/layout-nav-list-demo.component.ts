import { Component } from '@angular/core';

@Component({
  selector: 'layout-nav-list-demo',
  styleUrls: ['./layout-nav-list-demo.component.scss'],
  templateUrl: './layout-nav-list-demo.component.html',
})
export class LayoutNavListDemoComponent {}
