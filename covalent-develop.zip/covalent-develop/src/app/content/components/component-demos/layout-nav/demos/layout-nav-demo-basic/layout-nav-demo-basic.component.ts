import { Component } from '@angular/core';

@Component({
  selector: 'layout-nav-demo-basic',
  styleUrls: ['./layout-nav-demo-basic.component.scss'],
  templateUrl: './layout-nav-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class LayoutNavDemoBasicComponent {}
