import { Component } from '@angular/core';

@Component({
  selector: 'layout-nav-demo',
  styleUrls: ['./layout-nav-demo.component.scss'],
  templateUrl: './layout-nav-demo.component.html',
})
export class LayoutNavDemoComponent {}
