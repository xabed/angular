import { Component } from '@angular/core';

@Component({
  selector: 'layout-demo-basic',
  styleUrls: ['./layout-demo-basic.component.scss'],
  templateUrl: './layout-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class LayoutDemoBasicComponent {}
