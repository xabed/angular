import { Component } from '@angular/core';

@Component({
  selector: 'layout-demo',
  styleUrls: ['./layout-demo.component.scss'],
  templateUrl: './layout-demo.component.html',
})
export class LayoutDemoComponent {}
