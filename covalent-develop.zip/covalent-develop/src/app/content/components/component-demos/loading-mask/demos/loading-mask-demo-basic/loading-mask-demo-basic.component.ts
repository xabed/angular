import { Component } from '@angular/core';

@Component({
  selector: 'loading-mask-demo-basic',
  styleUrls: ['./loading-mask-demo-basic.component.scss'],
  templateUrl: './loading-mask-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class LoadingMaskDemoBasicComponent {}
