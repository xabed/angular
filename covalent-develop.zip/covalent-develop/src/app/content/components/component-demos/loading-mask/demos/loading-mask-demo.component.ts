import { Component } from '@angular/core';

@Component({
  selector: 'loading-mask-demo',
  styleUrls: ['./loading-mask-demo.component.scss'],
  templateUrl: './loading-mask-demo.component.html',
})
export class LoadingMaskDemoComponent {}
