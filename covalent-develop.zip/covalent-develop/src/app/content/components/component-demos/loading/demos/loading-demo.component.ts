import { Component } from '@angular/core';

@Component({
  selector: 'loading-demo',
  styleUrls: ['./loading-demo.component.scss'],
  templateUrl: './loading-demo.component.html',
})
export class LoadingDemoComponent {}
