import { Component } from '@angular/core';

@Component({
  selector: 'markdown-navigator-demo',
  styleUrls: ['./markdown-navigator-demo.component.scss'],
  templateUrl: './markdown-navigator-demo.component.html',
})
export class MarkdownNavigatorDemoComponent {}
