import { Component } from '@angular/core';

@Component({
  selector: 'markdown-demo-basic',
  styleUrls: ['./markdown-demo-basic.component.scss'],
  templateUrl: './markdown-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class MarkdownDemoBasicComponent {}
