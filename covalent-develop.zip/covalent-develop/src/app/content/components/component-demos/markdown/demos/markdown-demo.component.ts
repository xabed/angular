import { Component } from '@angular/core';

@Component({
  selector: 'markdown-demo',
  styleUrls: ['./markdown-demo.component.scss'],
  templateUrl: './markdown-demo.component.html',
})
export class MarkdownDemoComponent {}
