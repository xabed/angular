import { Component } from '@angular/core';

@Component({
  selector: 'message-demo',
  styleUrls: ['./message-demo.component.scss'],
  templateUrl: './message-demo.component.html',
})
export class MessageDemoComponent {}
