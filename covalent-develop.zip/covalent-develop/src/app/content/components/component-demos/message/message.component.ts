import { Component } from '@angular/core';

@Component({
  selector: 'message-demo',
  styleUrls: ['./message.component.scss'],
  templateUrl: './message.component.html',
  preserveWhitespaces: true,
})
export class MessageDemoComponent {}
