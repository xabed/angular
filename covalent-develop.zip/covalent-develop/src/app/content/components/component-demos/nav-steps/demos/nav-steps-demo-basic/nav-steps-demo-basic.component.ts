import { Component } from '@angular/core';

@Component({
  selector: 'nav-steps-demo-basic',
  styleUrls: ['./nav-steps-demo-basic.component.scss'],
  templateUrl: './nav-steps-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class NavStepsDemoBasicComponent {}
