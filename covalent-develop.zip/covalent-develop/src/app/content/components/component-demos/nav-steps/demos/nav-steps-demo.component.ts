import { Component } from '@angular/core';

@Component({
  selector: 'nav-steps-demo',
  styleUrls: ['./nav-steps-demo.component.scss'],
  templateUrl: './nav-steps-demo.component.html',
})
export class NavStepsDemoComponent {}
