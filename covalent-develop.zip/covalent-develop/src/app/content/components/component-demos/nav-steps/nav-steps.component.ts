import { Component } from '@angular/core';

@Component({
  selector: 'nav-steps-demo',
  styleUrls: ['./nav-steps.component.scss'],
  templateUrl: './nav-steps.component.html',
  preserveWhitespaces: true,
})
export class NavStepsDemoComponent {}
