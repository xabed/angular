import { Component } from '@angular/core';

@Component({
  selector: 'notifications-demo-basic',
  styleUrls: ['./notifications-demo-basic.component.scss'],
  templateUrl: './notifications-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class NotificationsDemoBasicComponent {}
