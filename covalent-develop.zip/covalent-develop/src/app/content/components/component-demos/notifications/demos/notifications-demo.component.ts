import { Component } from '@angular/core';

@Component({
  selector: 'notifications-demo',
  styleUrls: ['./notifications-demo.component.scss'],
  templateUrl: './notifications-demo.component.html',
})
export class NotificationsDemoComponent {}
