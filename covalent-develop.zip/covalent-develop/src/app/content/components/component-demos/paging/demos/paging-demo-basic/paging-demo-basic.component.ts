import { Component } from '@angular/core';

@Component({
  selector: 'paging-demo-basic',
  styleUrls: ['./paging-demo-basic.component.scss'],
  templateUrl: './paging-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class PagingDemoBasicComponent {}
