import { Component } from '@angular/core';

@Component({
  selector: 'paging-demo',
  styleUrls: ['./paging-demo.component.scss'],
  templateUrl: './paging-demo.component.html',
})
export class PagingDemoComponent {}
