import { Component } from '@angular/core';

@Component({
  selector: 'search-demo',
  styleUrls: ['./search-demo.component.scss'],
  templateUrl: './search-demo.component.html',
})
export class SearchDemoComponent {}
