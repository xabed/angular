import { Component } from '@angular/core';

@Component({
  selector: 'sidesheet-demo-basic',
  styleUrls: ['./sidesheet-demo-basic.component.scss'],
  templateUrl: './sidesheet-demo-basic.component.html',
  preserveWhitespaces: true,
})
export class SidesheetDemoBasicComponent {}
