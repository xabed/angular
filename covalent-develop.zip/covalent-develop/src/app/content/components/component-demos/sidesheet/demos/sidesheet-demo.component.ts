import { Component } from '@angular/core';

@Component({
  selector: 'sidesheet-demo',
  styleUrls: ['./sidesheet-demo.component.scss'],
  templateUrl: './sidesheet-demo.component.html',
})
export class SidesheetDemoComponent {}
