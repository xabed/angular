import { Component } from '@angular/core';

@Component({
  selector: 'steps-demo',
  styleUrls: ['./steps-demo.component.scss'],
  templateUrl: './steps-demo.component.html',
})
export class StepsDemoComponent {}
