import { Component } from '@angular/core';

@Component({
  selector: 'tab-select-demo',
  styleUrls: ['./tab-select-demo.component.scss'],
  templateUrl: './tab-select-demo.component.html',
})
export class TabSelectDemoComponent {}
