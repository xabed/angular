import { Component } from '@angular/core';

@Component({
  selector: 'text-editor-demo',
  styleUrls: ['./text-editor-demo.component.scss'],
  templateUrl: './text-editor-demo.component.html',
})
export class TextEditorDemoComponent {}
