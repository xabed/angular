import { Component } from '@angular/core';

@Component({
  selector: 'bar-demo',
  styleUrls: ['./bar-demo.component.scss'],
  templateUrl: './bar-demo.component.html',
})
export class BarDemoComponent {}
