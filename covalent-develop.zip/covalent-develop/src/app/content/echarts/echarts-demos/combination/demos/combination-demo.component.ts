import { Component } from '@angular/core';

@Component({
  selector: 'combination-demo',
  styleUrls: ['./combination-demo.component.scss'],
  templateUrl: './combination-demo.component.html',
})
export class CombinationDemoComponent {}
