import { Component } from '@angular/core';

@Component({
  selector: 'graph-demo',
  styleUrls: ['./graph-demo.component.scss'],
  templateUrl: './graph-demo.component.html',
})
export class GraphDemoComponent {}
