import { Component } from '@angular/core';

@Component({
  selector: 'line-demo',
  styleUrls: ['./line-demo.component.scss'],
  templateUrl: './line-demo.component.html',
})
export class LineDemoComponent {}
