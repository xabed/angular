import { Component } from '@angular/core';

@Component({
  selector: 'map-demo',
  styleUrls: ['./map-demo.component.scss'],
  templateUrl: './map-demo.component.html',
})
export class MapDemoComponent {}
