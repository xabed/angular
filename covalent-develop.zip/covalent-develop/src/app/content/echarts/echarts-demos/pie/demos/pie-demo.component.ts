import { Component } from '@angular/core';

@Component({
  selector: 'pie-demo',
  styleUrls: ['./pie-demo.component.scss'],
  templateUrl: './pie-demo.component.html',
})
export class PieDemoComponent {}
