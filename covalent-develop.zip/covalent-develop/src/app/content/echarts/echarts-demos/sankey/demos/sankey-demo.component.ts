import { Component } from '@angular/core';

@Component({
  selector: 'sankey-demo',
  styleUrls: ['./sankey-demo.component.scss'],
  templateUrl: './sankey-demo.component.html',
})
export class SankeyDemoComponent {}
