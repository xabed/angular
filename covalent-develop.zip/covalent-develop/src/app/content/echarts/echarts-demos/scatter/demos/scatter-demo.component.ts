import { Component } from '@angular/core';

@Component({
  selector: 'scatter-demo',
  styleUrls: ['./scatter-demo.component.scss'],
  templateUrl: './scatter-demo.component.html',
})
export class ScatterDemoComponent {}
