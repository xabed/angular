import { Component } from '@angular/core';

@Component({
  selector: 'tree-demo',
  styleUrls: ['./tree-demo.component.scss'],
  templateUrl: './tree-demo.component.html',
})
export class TreeDemoComponent {}
