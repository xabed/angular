import { Component } from '@angular/core';

@Component({
  selector: 'treemap-demo',
  styleUrls: ['./treemap-demo.component.scss'],
  templateUrl: './treemap-demo.component.html',
})
export class TreemapDemoComponent {}
