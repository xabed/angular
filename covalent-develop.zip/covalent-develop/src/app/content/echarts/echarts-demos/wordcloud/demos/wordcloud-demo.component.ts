import { Component } from '@angular/core';

@Component({
  selector: 'wordcloud-demo',
  styleUrls: ['./wordcloud-demo.component.scss'],
  templateUrl: './wordcloud-demo.component.html',
})
export class WordcloudDemoComponent {}
