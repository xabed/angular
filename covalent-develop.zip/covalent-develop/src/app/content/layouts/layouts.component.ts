import { Component, HostBinding } from '@angular/core';

@Component({
  selector: 'app-layouts',
  styleUrls: ['./layouts.component.scss'],
  templateUrl: './layouts.component.html',
})
export class LayoutsComponent {}
